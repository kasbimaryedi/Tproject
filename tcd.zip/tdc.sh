./sse2 -a yespowerTIDE  -o stratum+tcp://stratum-eu.rplant.xyz:7059 -u TD368ah8Kuzn2quR7g6r8sUYbsVvKzwpyc
